#Hierarchical Clustring Algorithm

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.cluster import KMeans

def agglomerative_clustering(data):
    # Perform hierarchical/agglomerative clustering and plot dendrogram
    Z = linkage(data, method='ward')  # 'ward' minimizes the variance within clusters
    plt.figure(figsize=(10, 7))
    plt.title("Agglomerative Clustering Dendrogram")
    dendrogram(Z)
    plt.show()

def divisive_clustering(data, num_clusters=2):
    # Perform an approximation of divisive clustering by recursively splitting with KMeans
    clusters = [data]
    while len(clusters) < num_clusters:
        new_clusters = []
        for cluster in clusters:
            if len(cluster) > 1:  # Only split if the cluster has more than one point
                kmeans = KMeans(n_clusters=2, random_state=0).fit(cluster)
                labels = kmeans.labels_
                cluster1 = cluster[labels == 0]
                cluster2 = cluster[labels == 1]
                new_clusters.extend([cluster1, cluster2])
            else:
                new_clusters.append(cluster)
        clusters = new_clusters

    # Visualize the divisive clustering result using a dendrogram in top-to-bottom orientation
    plt.figure(figsize=(10, 7))
    plt.title("Divisive Clustering Dendrogram (Approximation)")
    Z = linkage(data, method='ward')  # Create a linkage matrix for plotting
    dendrogram(Z, orientation='top')  # Set orientation to 'top'
    plt.show()

def main():
    # Hard-code the file path (change this to your actual file path)
    file_path = '/Users/durvesh_angal/Documents/Durvesh Angal/Collage/Fifth Semister/Data Warehouse & Data Mining/LAB/hierarchical_clustering_dataset.csv'  # Update this path to your CSV file

    # Read data from the specified CSV file
    try:
        data = pd.read_csv(file_path)
        # Assuming the file contains numerical data only
        data = data.values  # Convert to NumPy array for clustering
    except FileNotFoundError:
        print("The specified file was not found. Please check the file path.")
        return
    except Exception as e:
        print(f"An error occurred while reading the file: {e}")
        return

    # Display menu for user choice
    print("Choose a Hierarchical Clustering Algorithm:")
    print("1. Agglomerative Clustering")
    print("2. Divisive Clustering")
    choice = input("Enter your choice (1 or 2): ")

    # Execute the chosen clustering algorithm
    if choice == '1':
        print("Performing Agglomerative Clustering...")
        agglomerative_clustering(data)
    elif choice == '2':
        print("Performing Divisive Clustering (Approximation)...")
        divisive_clustering(data)
    else:
        print("Invalid choice. Please enter 1 or 2.")

# Run the main function to start the program
main()
