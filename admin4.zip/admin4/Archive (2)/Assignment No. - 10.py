#Decision Tree Algorithm

import pandas as pd
import math

# Function to calculate entropy
def calculate_entropy(df, target_attribute):
    # Count the occurrences of each class label in the target attribute
    class_counts = df[target_attribute].value_counts()
    
    # Calculate entropy
    total_count = len(df)
    entropy = 0.0
    
    for count in class_counts:
        probability = count / total_count
        entropy -= probability * math.log2(probability) if probability > 0 else 0
    
    return entropy

# Function to calculate information gain
def calculate_information_gain(df, attribute, target_attribute):
    # Calculate entropy of the entire dataset
    total_entropy = calculate_entropy(df, target_attribute)
    
    # Calculate the weighted entropy for each value of the attribute
    attribute_values = df[attribute].unique()
    weighted_entropy = 0.0
    
    for value in attribute_values:
        subset = df[df[attribute] == value]
        subset_entropy = calculate_entropy(subset, target_attribute)
        weighted_entropy += (len(subset) / len(df)) * subset_entropy
    
    # Information gain is the reduction in entropy
    information_gain = total_entropy - weighted_entropy
    return information_gain

# Function to determine the best attribute to split on
def find_best_split(df, target_attribute):
    best_gain = -1
    best_attribute = None
    
    for attribute in df.columns:
        if attribute != target_attribute:  # Skip the target attribute
            info_gain = calculate_information_gain(df, attribute, target_attribute)
            print(f"Information Gain for '{attribute}': {info_gain:.4f}")
            
            if info_gain > best_gain:
                best_gain = info_gain
                best_attribute = attribute
    
    return best_attribute

# Load the dataset from a file
def load_dataset(file_path):
    return pd.read_csv(file_path)

# Main function to run the decision tree logic
def main():
    # Provide the path to your dataset
    file_path = '/Users/durvesh_angal/Documents/Durvesh Angal/Collage/Fifth Semister/Data Warehouse & Data Mining/LAB/Decision Tree Algorithm.csv'
    df = load_dataset(file_path)
    
    # Target attribute column name (you can change it according to your dataset)
    target_attribute = 'Play Football'
    
    # Calculate and display entropy of the entire dataset
    print("Calculating entropy of the entire dataset:")
    total_entropy = calculate_entropy(df, target_attribute)
    print(f"Entropy of the entire dataset: {total_entropy:.4f}\n")
    
    # Calculate information gain for each attribute
    print("Calculating information gain for each attribute:")
    best_attribute = find_best_split(df, target_attribute)
    
    # Display the best attribute to split on
    print(f"\nThe best attribute to split on is: {best_attribute}")

if __name__ == "__main__":
    main()
