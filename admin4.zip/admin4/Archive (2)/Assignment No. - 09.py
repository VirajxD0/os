import pandas as pd
import numpy as np
import json

from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

import warnings
warnings.filterwarnings("ignore")

# Load the dataset
df = pd.read_excel("weather.xlsx")
print(df)

# Drop any rows with missing values
df1 = df.dropna()
print(df1)

# Replace categorical values with numerical ones
df1["outlook"].replace({"overcast": 1, "rainy": 2, "sunny": 3}, inplace=True)
df1["temperature"].replace({"mild": 0, "hot": 1, "cool": 2}, inplace=True)
df1["humidity"].replace({"high": 0, "normal": 1}, inplace=True)
df1["play"].replace({"yes": 1, "no": 0}, inplace=True)

# Prepare feature and target variables
x = df1.drop('play', axis=1)
y = df1["play"]

# Split the data into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=1, stratify=y)

# Gaussian Naive Bayes model
gnb_model = GaussianNB()
gnb_model.fit(x_train, y_train)

# Predictions on the test set
y_pred = gnb_model.predict(x_test)

# Confusion matrix and evaluation metrics
cnf_matrix = confusion_matrix(y_pred, y_test)
print("Confusion Matrix:\n", cnf_matrix)
print("-" * 60)

accuracy = accuracy_score(y_pred, y_test)
print("Accuracy:\n", accuracy)
print("-" * 60)

clf_report = classification_report(y_pred, y_test)
print("Classification Report:\n", clf_report)

# Evaluate the model on the training set
y_pred_train = gnb_model.predict(x_train)

cnf_matrix_train = confusion_matrix(y_pred_train, y_train)
print("Training Confusion Matrix:\n", cnf_matrix_train)
print("-" * 60)

accuracy_train = accuracy_score(y_pred_train, y_train)
print("Training Accuracy:\n", accuracy_train)
print("-" * 60)

clf_report_train = classification_report(y_pred_train, y_train)
print("Training Classification Report:\n", clf_report_train)

# ------ Single User Input Testing ------
column_names = x.columns
outlook_value = {"overcast": 1, "rainy": 2, "sunny": 3}
temperature_value = {"mild": 0, "hot": 1, "cool": 2}
humidity_value = {"high": 0, "normal": 1}

json_data = {
    "outlook": outlook_value,
    "temperature": temperature_value,
    "humidity": humidity_value,
    "columns": list(column_names)
}


# Saving json data to file for future reference
with open("Project_data_NB.json", "w") as f:
    json.dump(json_data, f)

# Example user input
outlook = "rainy"
temperature = "mild"
humidity = "high"
windy = 1.0

# Creating test array for prediction
test_array = np.zeros(len(column_names))

test_array[0] = json_data["outlook"][outlook]
test_array[1] = json_data["temperature"][temperature]
test_array[2] = json_data["humidity"][humidity]
test_array[3] = windy

print("Test Array: ", test_array)

# Predict whether to play or not using the trained model
play = gnb_model.predict([test_array])[0]

if play == 1:
    print("Yes, Play is happening")
else:
    print("No, Play is not happening")
