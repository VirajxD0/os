import numpy as np
import pandas as pd  # Import pandas to read CSV files and format output

def initialize_centroids(data, k):
    # Randomly choose k data points as initial centroids
    indices = np.random.choice(data.shape[0], k, replace=False)
    centroids = data[indices]
    print("Initial Centroids:")
    print(pd.DataFrame(centroids, columns=["Age", "Amount"]))
    return centroids

def calculate_distances(data, centroids):
    # Calculate the Euclidean distance from each point to each centroid
    distances = np.sqrt(((data - centroids[:, np.newaxis]) ** 2).sum(axis=2))
    print("\nDistances from each point to each centroid:")
    distances_df = pd.DataFrame(distances.T, columns=[f"Centroid {i}" for i in range(len(centroids))])
    print(distances_df)
    return distances

def assign_clusters(distances):
    # Assign each point to the nearest centroid
    labels = np.argmin(distances, axis=0)
    print("\nCluster assignments for each point:")
    assignments_df = pd.DataFrame(labels, columns=["Cluster"])
    print(assignments_df)
    return labels

def update_centroids(data, labels, k):
    # Recompute the centroids as the mean of points in each cluster
    new_centroids = np.array([data[labels == i].mean(axis=0) for i in range(k)])
    print("\nUpdated Centroids:")
    print(pd.DataFrame(new_centroids, columns=["Age", "Amount"]))
    return new_centroids

def k_means(data, k, max_iterations=100, tolerance=1e-4):
    # Step 1: Initialize centroids
    centroids = initialize_centroids(data, k)
    
    for iteration in range(max_iterations):
        print(f"\nIteration {iteration + 1}:")

        # Step 2: Calculate distances and assign clusters
        distances = calculate_distances(data, centroids)
        labels = assign_clusters(distances)
        
        # Step 3: Update centroids
        new_centroids = update_centroids(data, labels, k)
        
        # Step 4: Check for convergence (if centroids don’t change significantly)
        if np.all(np.abs(new_centroids - centroids) < tolerance):
            print("\nConvergence reached! Final centroids:")
            print(pd.DataFrame(new_centroids, columns=["Age", "Amount"]))
            break
        
        centroids = new_centroids
    
    return labels, centroids

# Load data from CSV file
file_path = "/Users/durvesh_angal/Documents/Durvesh Angal/Collage/Fifth Semister/Data Warehouse & Data Mining/LAB/K-Means Clustring.csv"
data_df = pd.read_csv(file_path)  # Load the data into a DataFrame
data = data_df[['Age', 'Amount']].values  # Use only 'Age' and 'Amount' for clustering

k = 2  # Number of clusters
labels, centroids = k_means(data, k)
print("\nFinal Cluster labels and Centroids:")

# Display final labels and centroids in table format
final_labels_df = pd.DataFrame(labels, columns=["Cluster"])
final_centroids_df = pd.DataFrame(centroids, columns=["Age", "Amount"])
print("\nFinal Cluster Labels:")
print(final_labels_df)
print("\nFinal Centroids:")
print(final_centroids_df)
