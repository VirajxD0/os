-- Step 1: Create the Database
CREATE DATABASE OrderManagementWarehouse;

-- Step 2: Use the Database
USE OrderManagementWarehouse;

-- Step 3: Create Dimension Tables

-- Customer Table
CREATE TABLE Customer (
	customer_id INT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    billing_address VARCHAR(255),
    shipping_address VARCHAR(255)
);

-- Product Table
CREATE TABLE Product (
	product_id INT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    product_category VARCHAR(100)
);

-- Promotion Table
CREATE TABLE Promotion (
	promotion_id INT PRIMARY KEY,
    promotion_name VARCHAR(100) NOT NULL,
    discount_percentage DECIMAL(5,2)
);

-- Sales Representative Table
CREATE TABLE Sales_Representative (
	sales_rep_id INT PRIMARY KEY,
    sales_rep_name VARCHAR(100) NOT NULL,
    region VARCHAR(100)
);

-- Currency Table
CREATE TABLE Currency (
	currency_id INT PRIMARY KEY,
    currency_name VARCHAR(50) NOT NULL,
    exchange_rate_to_dollar DECIMAL(10,4) NOT NULL
);

-- Step 4: Create Fact Table

CREATE TABLE Fact_Orders (
	order_id INT PRIMARY KEY,
    customer_id INT,
    product_id INT,
    promotion_id INT,
    sales_rep_id INT,
    currency_id INT,
    order_date DATE,
    requested_ship_date DATE,
    quantity INT NOT NULL,
    gross_amount DECIMAL(10,2) NOT NULL,
    discount_amount DECIMAL(10,2) NOT NULL,
    net_amount DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id),
    FOREIGN KEY (product_id) REFERENCES Product(product_id),
    FOREIGN KEY (promotion_id) REFERENCES Promotion(promotion_id),
    FOREIGN KEY (sales_rep_id) REFERENCES Sales_Representative(sales_rep_id),
    FOREIGN KEY (currency_id) REFERENCES Currency(currency_id)
);

-- Insert Data into Customer
INSERT INTO Customer (customer_id, customer_name, billing_address, shipping_address) 
VALUES 
(1, 'Luna Corp', '123 Main St, NY', '456 Elm St, NY'),
(2, 'Orion Industries', '789 Maple St, London', '101 Pine St, London'),
(3, 'Phoenix LLC', '234 Oak St, Tokyo', '678 Cedar St, Tokyo'),
(4, 'Aquila Group', '321 Birch St, Paris', '654 Walnut St, Paris'),
(5, 'Gemini Co', '567 Ash St, Berlin', '890 Willow St, Berlin');

-- Insert Data into Product
INSERT INTO Product (product_id, product_name, product_category) 
VALUES 
(1, 'Widget A', 'Electronics'),
(2, 'Gadget B', 'Hardware'),
(3, 'Device C', 'Software'),
(4, 'Tool D', 'Tools'),
(5, 'Instrument E', 'Instruments');

-- Insert Data into Promotion
INSERT INTO Promotion (promotion_id, promotion_name, discount_percentage) 
VALUES 
(1, 'Winter Sale', 10.00),
(2, 'Spring Offer', 15.00),
(3, 'Summer Deal', 20.00),
(4, 'Autumn Discount', 25.00),
(5, 'Holiday Special', 30.00);

-- Insert Data into Sales_Representative
INSERT INTO Sales_Representative (sales_rep_id, sales_rep_name, region) 
VALUES 
(1, 'Alex Mercer', 'North America'),
(2, 'Jade Carter', 'Europe'),
(3, 'Rei Tanaka', 'Asia'),
(4, 'Claude Dupont', 'Europe'),
(5, 'Hans Müller', 'Europe');

-- Insert Data into Currency
INSERT INTO Currency (currency_id, currency_name, exchange_rate_to_dollar) 
VALUES 
(1, 'Dollar', 1.0000),
(2, 'Euro', 1.1000),
(3, 'Dirham', 0.2722),
(4, 'Yen', 0.0091),
(5, 'Pound', 1.3000);

-- Insert Data into Fact_Orders
INSERT INTO Fact_Orders (order_id, customer_id, product_id, promotion_id, sales_rep_id, currency_id, order_date, requested_ship_date, quantity, gross_amount, discount_amount, net_amount) 
VALUES 
(1, 1, 1, 1, 1, 1, '2024-01-15', '2024-01-20', 100, 5000.00, 500.00, 4500.00),
(2, 2, 2, 2, 2, 2, '2024-02-10', '2024-02-18', 150, 7500.00, 1125.00, 6375.00),
(3, 3, 3, 3, 3, 4, '2024-03-05', '2024-03-12', 200, 12000.00, 2400.00, 9600.00),
(4, 4, 4, 4, 4, 3, '2024-04-08', '2024-04-15', 250, 15000.00, 3750.00, 11250.00),
(5, 5, 5, 5, 5, 5, '2024-05-20', '2024-05-25', 300, 18000.00, 5400.00, 12600.00);
