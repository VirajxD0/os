from itertools import combinations
from tabulate import tabulate

# Function to calculate support
def get_support(itemset, transactions):
    return sum(1 for transaction in transactions if set(itemset).issubset(transaction)) / len(transactions)

# Function to find frequent itemsets and collect step-by-step information
def apriori(transactions, min_support):
    # Initialize frequent 1-itemsets
    itemsets = set(tuple([item]) for transaction in transactions for item in transaction)
    all_frequent_itemsets = {}  # Store all frequent itemsets over multiple iterations
    step_details = []  # Collect descriptions and tables to show at each step

    # Step 1: Analyze Transactions and unique items
    unique_items = sorted(set(item for transaction in transactions for item in transaction))
    item_count = {item: sum(item in transaction for transaction in transactions) for item in unique_items}
    step_details.append(("Initial Transactions", [["Item", "Count"]] + [[item, count] for item, count in item_count.items()]))

    # Step 2: Set Support Threshold
    support_threshold = min_support
    step_details.append(("Support Threshold Calculation", [["Minimum Support", min_support]]))

    # Generate frequent itemsets
    k = 1
    current_frequent_itemsets = set()
    while itemsets:
        # Step 3: Count Unique k-Item Sets
        itemset_support = {itemset: get_support(itemset, transactions) for itemset in itemsets}
        all_frequent_itemsets.update(itemset_support)
        step_details.append((f"Count Unique {k}-Item Sets", [["Item Set", "Support"]] + [[itemset, f"{support:.2f}"] for itemset, support in itemset_support.items()]))

        # Step 4: Remove Low Support Items
        frequent_itemsets_k = set(itemset for itemset, support in itemset_support.items() if support >= support_threshold)
        step_details.append((f"Remove Low Support {k}-Item Sets", [["Item Set"]] + [[itemset] for itemset in frequent_itemsets_k]))

        # Generate (k+1)-itemsets by joining frequent k-itemsets
        if frequent_itemsets_k:
            new_itemsets = set()
            frequent_list = sorted(frequent_itemsets_k)
            for i in range(len(frequent_list)):
                for j in range(i+1, len(frequent_list)):
                    l1 = frequent_list[i]
                    l2 = frequent_list[j]
                    # Join step: combine itemsets that share the first k-1 items
                    if l1[:-1] == l2[:-1]:
                        new_item = tuple(sorted(set(l1).union(set(l2))))
                        if len(new_item) == k + 1:
                            new_itemsets.add(new_item)
            # Prune step: remove itemsets with any infrequent subset
            pruned_itemsets = set()
            for itemset in new_itemsets:
                subsets = combinations(itemset, k)
                if all(tuple(sorted(subset)) in frequent_itemsets_k for subset in subsets):
                    pruned_itemsets.add(itemset)
            new_itemsets = pruned_itemsets
            if new_itemsets:
                step_details.append((f"Generate Frequent {k+1}-Item Sets", [["Item Set"]] + [[itemset] for itemset in sorted(new_itemsets)]))
            itemsets = new_itemsets
            k += 1
        else:
            break  # No more itemsets to process

    # Final Output
    final_frequent_itemsets = {itemset: support for itemset, support in all_frequent_itemsets.items() if support >= support_threshold}
    step_details.append(("Final Frequent Item Sets", [["Item Set", "Support"]] + [[itemset, f"{support:.2f}"] for itemset, support in final_frequent_itemsets.items()]))
    
    return final_frequent_itemsets, step_details, all_frequent_itemsets

# Example transactions dataset
transactions = [
    set(['bread', 'milk', 'diaper']),
    set(['bread', 'diaper', 'beer', 'egg']),
    set(['milk', 'diaper', 'beer', 'coke']),
    set(['bread', 'milk', 'diaper', 'beer']),
    set(['bread', 'milk', 'diaper', 'coke'])
]

# Parameters: minimum support
min_support = 0.5

# Get frequent itemsets and step details
frequent_itemsets, step_details, all_frequent_itemsets = apriori(transactions, min_support)

# Define the specific itemset to calculate confidence for: ('bread', 'diaper', 'milk')
target_itemset = tuple(sorted(['bread', 'diaper', 'milk']))

# Find support for the full itemset and its subsets
support_target = all_frequent_itemsets.get(target_itemset, 0)
support_bread_milk = all_frequent_itemsets.get(tuple(sorted(['bread', 'milk'])), 0)
support_bread_diaper = all_frequent_itemsets.get(tuple(sorted(['bread', 'diaper'])), 0)
support_milk_diaper = all_frequent_itemsets.get(tuple(sorted(['milk', 'diaper'])), 0)

# Calculate confidence for each rule
confidence_bread_milk_to_diaper = (support_target / support_bread_milk) * 100 if support_bread_milk else 0
confidence_bread_diaper_to_milk = (support_target / support_bread_diaper) * 100 if support_bread_diaper else 0
confidence_milk_diaper_to_bread = (support_target / support_milk_diaper) * 100 if support_milk_diaper else 0

# Prepare the confidence results table
confidence_table = [
    ["Rule", "Confidence (%)"],
    ["{Bread, Milk} -> {Diaper}", f"{confidence_bread_milk_to_diaper:.2f}%"],
    ["{Bread, Diaper} -> {Milk}", f"{confidence_bread_diaper_to_milk:.2f}%"],
    ["{Milk, Diaper} -> {Bread}", f"{confidence_milk_diaper_to_bread:.2f}%"]
]

# Print each step detail and associated table
for description, table in step_details:
    print(f"\n=== {description} ===")
    print(tabulate(table, headers="firstrow", tablefmt="grid"))

# Print the confidence results
print("\n=== Confidence Results ===")
print(tabulate(confidence_table, headers="firstrow", tablefmt="grid"))
