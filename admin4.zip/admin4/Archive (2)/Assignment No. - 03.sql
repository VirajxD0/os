CREATE DATABASE BookManagementWarehouse;

USE BookManagementWarehouse;

CREATE TABLE Book_Type (
	book_type_id INT PRIMARY KEY, 
    book_type_name VARCHAR(100) NOT NULL
);

CREATE TABLE Location (
	location_id INT PRIMARY KEY,
    location_name VARCHAR(100) NOT NULL
);

CREATE TABLE Author (
	author_id INT PRIMARY KEY,
    author_name VARCHAR(100) NOT NULL,
    author_age INT NOT NULL,
    author_country VARCHAR(100) NOT NULL
);

CREATE TABLE Publication (
	publication_id INT PRIMARY KEY,
    publication_name VARCHAR(100) NOT NULL,
    publication_country VARCHAR(100) NOT NULL,
    publication_year INT NOT NULL
);

CREATE TABLE Fact_Sales (
	sale_id INT PRIMARY KEY,
	book_type_id INT,
	location_id INT,
	author_id INT,
	publication_id INT,
	quantity INT NOT NULL,
	profit DECIMAL(10, 2) NOT NULL,
	FOREIGN KEY (book_type_id) REFERENCES Book_Type(book_type_id),
	FOREIGN KEY (location_id) REFERENCES Location(location_id),
	FOREIGN KEY (author_id) REFERENCES Author(author_id),
	FOREIGN KEY (publication_id) REFERENCES Publication(publication_id)
);

INSERT INTO Book_Type (book_type_id, book_type_name) 
VALUES 
(1, 'Fiction'), 
(2, 'Non-Fiction'), 
(3, 'Science Fiction'), 
(4, 'Biography'),
(5, 'Fantasy');

INSERT INTO Location (location_id, location_name) 
VALUES 
(1, 'New York'), 
(2, 'London'), 
(3, 'Tokyo'), 
(4, 'Paris'),
(5, 'Berlin');

INSERT INTO Author (author_id, author_name, author_age, author_country) 
VALUES 
(1, 'Aurelia Quinn', 42, 'Canada'), 
(2, 'Balthazar Elric', 50, 'France'), 
(3, 'Seraphina Thorn', 36, 'Australia'), 
(4, 'Caspian Voss', 48, 'Germany'),
(5, 'Elowen Blythe', 29, 'Ireland');

INSERT INTO Publication (publication_id, publication_name, publication_country, publication_year) 
VALUES 
(1, 'HarperCollins', 'USA', 2015), 
(2, 'Penguin Books', 'UK', 2018), 
(3, 'Kodansha', 'Japan', 2017), 
(4, 'Gallimard', 'France', 2016),
(5, 'Rowohlt Verlag', 'Germany', 2019);

INSERT INTO Fact_Sales (sale_id, book_type_id, location_id, author_id, publication_id, quantity, profit)
VALUES 
(1, 1, 1, 1, 1, 100, 5000.00),
(2, 2, 2, 2, 2, 150, 7500.00),
(3, 3, 3, 3, 3, 200, 12000.00),
(4, 4, 4, 4, 4, 250, 15000.00),
(5, 5, 5, 5, 5, 300, 18000.00);