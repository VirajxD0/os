-- Step 1: Create the database
CREATE DATABASE HouseRentalStarSchema;

-- Step 2: Use the database
USE HouseRentalStarSchema;

-- Step 3: Create Dimension Tables

-- Tenants Dimension
CREATE TABLE Tenants (
TenantID INT PRIMARY KEY,
TenantName VARCHAR(50),
Age INT,
ContactNumber VARCHAR(15),
RentalHistory VARCHAR(100)
);

-- Properties Dimension
CREATE TABLE Properties (
PropertyID INT PRIMARY KEY,
PropertyType VARCHAR(50),
NumberOfRooms INT,
RentalPrice DECIMAL(10, 2)
);

-- Locations Dimension
CREATE TABLE Locations (
LocationID INT PRIMARY KEY,
City VARCHAR(50),
Neighborhood VARCHAR(50)
);

-- Time Dimension
CREATE TABLE Time (
TimeID INT PRIMARY KEY,
Date DATE,
Month INT,
Quarter INT,
Year INT
);

-- Step 4: Create Fact Table

-- Rentals Fact Table
CREATE TABLE Rentals (
RentalID INT PRIMARY KEY,
PropertyID INT,
TenantID INT,
LocationID INT,
TimeID INT,
TotalRental DECIMAL(10, 2),
PaymentStatus VARCHAR(20),
FOREIGN KEY (PropertyID) REFERENCES Properties(PropertyID),
FOREIGN KEY (TenantID) REFERENCES Tenants(TenantID),
FOREIGN KEY (LocationID) REFERENCES Locations(LocationID),
FOREIGN KEY (TimeID) REFERENCES Time(TimeID)
);

-- Step 5: Insert Data

-- Insert data into Tenants
INSERT INTO Tenants (TenantID, TenantName, Age, ContactNumber, RentalHistory) VALUES
(1, 'Rahul Mehra', 35, '9876543210', 'Good'),
(2, 'Priya Iyer', 29, '9876543211', 'Average'),
(3, 'Amit Patel', 42, '9876543212', 'Excellent'),
(4, 'Neha Sharma', 31, '9876543213', 'Good'),
(5, 'Suresh Reddy', 45, '9876543214', 'Average'),
(6, 'Pooja Singh', 28, '9876543215', 'Good'),
(7, 'Rajesh Khanna', 38, '9876543216', 'Poor');

-- Insert data into Properties
INSERT INTO Properties (PropertyID, PropertyType, NumberOfRooms, RentalPrice) VALUES
(1, 'Apartment', 2, 20000),
(2, 'Villa', 4, 50000),
(3, 'Apartment', 3, 25000),
(4, 'Independent House', 5, 35000),
(5, 'Studio', 1, 15000),
(6, 'Penthouse', 4, 60000),
(7, 'Apartment', 2, 22000);

-- Insert data into Locations
INSERT INTO Locations (LocationID, City, Neighborhood) VALUES
(1, 'Mumbai', 'Andheri'),
(2, 'Bangalore', 'Whitefield'),
(3, 'Delhi', 'South Delhi'),
(4, 'Hyderabad', 'Banjara Hills'),
(5, 'Chennai', 'Adyar'),
(6, 'Kolkata', 'Salt Lake'),
(7, 'Pune', 'Hinjewadi');

-- Insert data into Time
INSERT INTO Time (TimeID, Date, Month, Quarter, Year) VALUES
(1, '2024-01-01', 1, 1, 2024),
(2, '2024-03-01', 3, 1, 2024),
(3, '2024-05-01', 5, 2, 2024),
(4, '2024-06-01', 6, 2, 2024),
(5, '2024-07-01', 7, 3, 2024),
(6, '2024-08-01', 8, 3, 2024),
(7, '2024-09-01', 9, 3, 2024);

-- Insert data into Rentals Fact Table
INSERT INTO Rentals (RentalID, PropertyID, TenantID, LocationID, TimeID, TotalRental, PaymentStatus) VALUES
(1, 1, 1, 1, 1, 20000, 'Paid'),
(2, 2, 2, 2, 2, 50000, 'Pending'),
(3, 3, 3, 3, 3, 25000, 'Paid'),
(4, 4, 4, 4, 4, 35000, 'Paid'),
(5, 5, 5, 5, 5, 15000, 'Pending'),
(6, 6, 6, 6, 6, 60000, 'Paid'),
(7, 7, 7, 7, 7, 22000, 'Pending');