-- Step 1: Create the database
CREATE DATABASE HealthcareDB;

-- Step 2: Use the database
USE HealthcareDB;

-- Step 3: Create the tables

-- 1. Patients Dimension
CREATE TABLE Patients (
    PatientID INT PRIMARY KEY,
    PatientName VARCHAR(50),
    Age INT,
    Gender VARCHAR(10),
    City VARCHAR(50)
);

-- 2. Doctors Dimension
CREATE TABLE Doctors (
    DoctorID INT PRIMARY KEY,
    DoctorName VARCHAR(50),
    Specialization VARCHAR(50),
    ContactNumber VARCHAR(15)
);

-- 3. Hospitals Dimension
CREATE TABLE Hospitals (
    HospitalID INT PRIMARY KEY,
    HospitalName VARCHAR(50),
    Location VARCHAR(50),
    Department VARCHAR(50)
);

-- 4. Treatments Dimension
CREATE TABLE Treatments (
    TreatmentID INT PRIMARY KEY,
    TreatmentName VARCHAR(50),
    Cost DECIMAL(10, 2)
);

-- 5. Time Dimension
CREATE TABLE Time (
    TimeID INT PRIMARY KEY,
    VisitDate DATE,
    Month INT,
    Quarter INT,
    Year INT
);

-- 6. Fact Table: Visits (create this last to ensure referenced tables exist)
CREATE TABLE Visits (
    VisitID INT PRIMARY KEY,
    PatientID INT,
    DoctorID INT,
    HospitalID INT,
    TreatmentID INT,
    TimeID INT,
    TotalCost DECIMAL(10, 2),
    FOREIGN KEY (PatientID) REFERENCES Patients(PatientID),
    FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID),
    FOREIGN KEY (HospitalID) REFERENCES Hospitals(HospitalID),
    FOREIGN KEY (TreatmentID) REFERENCES Treatments(TreatmentID),
    FOREIGN KEY (TimeID) REFERENCES Time(TimeID)
);


-- Step 4: Insert the data into the tables

-- Insert data into Patients
INSERT INTO Patients (PatientID, PatientName, Age, Gender, City) VALUES
(1, 'Rajesh Sharma', 45, 'Male', 'Delhi'),
(2, 'Sita Devi', 32, 'Female', 'Mumbai'),
(3, 'Anil Kumar', 29, 'Male', 'Bangalore'),
(4, 'Meera Patel', 50, 'Female', 'Chennai'),
(5, 'Vikram Singh', 40, 'Male', 'Hyderabad'),
(6, 'Aarti Kaur', 28, 'Female', 'Kolkata'),
(7, 'Manoj Joshi', 38, 'Male', 'Pune');

-- Insert data into Doctors
INSERT INTO Doctors (DoctorID, DoctorName, Specialization, ContactNumber) VALUES
(1, 'Dr. Ramesh Rao', 'Cardiologist', '9876543210'),
(2, 'Dr. Kavita Nair', 'Neurologist', '9876543211'),
(3, 'Dr. Sanjay Verma', 'Orthopedic', '9876543212'),
(4, 'Dr. Priya Iyer', 'Dermatologist', '9876543213'),
(5, 'Dr. Anil Sood', 'ENT Specialist', '9876543214'),
(6, 'Dr. Neeta Sharma', 'Pediatrician', '9876543215'),
(7, 'Dr. Ajay Desai', 'Gastroenterologist', '9876543216');

-- Insert data into Hospitals
INSERT INTO Hospitals (HospitalID, HospitalName, Location, Department) VALUES
(1, 'Apollo Hospital', 'Delhi', 'Cardiology'),
(2, 'Fortis Hospital', 'Mumbai', 'Neurology'),
(3, 'Manipal Hospital', 'Bangalore', 'Orthopedics'),
(4, 'Global Hospital', 'Chennai', 'Dermatology'),
(5, 'Yashoda Hospital', 'Hyderabad', 'ENT'),
(6, 'AMRI Hospital', 'Kolkata', 'Pediatrics'),
(7, 'Ruby Hall Clinic', 'Pune', 'Gastroenterology');

-- Insert data into Treatments
INSERT INTO Treatments (TreatmentID, TreatmentName, Cost) VALUES
(1, 'Heart Surgery', 250000),
(2, 'Brain MRI', 120000),
(3, 'Joint Replacement', 180000),
(4, 'Skin Treatment', 60000),
(5, 'Ear Surgery', 90000),
(6, 'Vaccination', 5000),
(7, 'Endoscopy', 35000);

-- Insert data into Time
INSERT INTO Time (TimeID, VisitDate, Month, Quarter, Year) VALUES
(1, '2024-01-15', 1, 1, 2024),
(2, '2024-03-22', 3, 1, 2024),
(3, '2024-06-05', 6, 2, 2024),
(4, '2024-09-10', 9, 3, 2024),
(5, '2024-12-01', 12, 4, 2024),
(6, '2024-02-18', 2, 1, 2024),
(7, '2024-11-20', 11, 4, 2024);

-- Insert data into Visits (Fact Table)
INSERT INTO Visits (VisitID, PatientID, DoctorID, HospitalID, TreatmentID, TimeID, TotalCost) VALUES
(1, 1, 1, 1, 1, 1, 250000),
(2, 2, 2, 2, 2, 2, 120000),
(3, 3, 3, 3, 3, 3, 180000),
(4, 4, 4, 4, 4, 4, 60000),
(5, 5, 5, 5, 5, 5, 90000),
(6, 6, 6, 6, 6, 6, 5000),
(7, 7, 7, 7, 7, 7, 35000);
