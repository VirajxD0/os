#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>

// Shared resource
int shared_data = 0;

// Semaphores and counters
sem_t rw_mutex;    // Semaphore to control access to shared resource
sem_t mutex;       // Semaphore to protect the read_count variable
int read_count = 0; // Number of readers accessing the shared resource

// Function to get current time as a string
void get_time(char *time_str) {
    time_t now = time(NULL);
    strftime(time_str, 100, "%Y-%m-%d %H:%M:%S", localtime(&now));
}

// Reader function
void* reader(void* arg) {
    int reader_id = *((int*)arg);
    char time_str[100];

    while (1) {
        sem_wait(&mutex);          // Lock mutex for read_count
        read_count++;
        if (read_count == 1) {
            sem_wait(&rw_mutex);  // If first reader, lock rw_mutex
        }
        sem_post(&mutex);          // Unlock mutex for read_count

        // Reading shared data
        get_time(time_str);
        printf("Reader %d read data: %d at %s\n", reader_id, shared_data, time_str);

        sem_wait(&mutex);          // Lock mutex for read_count
        read_count--;
        if (read_count == 0) {
            sem_post(&rw_mutex);  // If last reader, unlock rw_mutex
        }
        sem_post(&mutex);          // Unlock mutex for read_count

        sleep(rand() % 3);  // Simulate reading time
    }
}

// Writer function
void* writer(void* arg) {
    int writer_id = *((int*)arg);
    char time_str[100];

    while (1) {
        sem_wait(&rw_mutex);  // Lock rw_mutex to access shared resource

        // Writing to shared data
        shared_data = rand() % 100;
        get_time(time_str);
        printf("Writer %d wrote data: %d at %s\n", writer_id, shared_data, time_str);

        sem_post(&rw_mutex);  // Unlock rw_mutex

        sleep(rand() % 3);  // Simulate writing time
    }
}

int main() {
    pthread_t readers[5], writers[2];  // Threads for readers and writers
    int reader_ids[5], writer_ids[2]; // IDs for readers and writers

    // Initialize semaphores
    sem_init(&rw_mutex, 0, 1);  // Binary semaphore for rw_mutex
    sem_init(&mutex, 0, 1);     // Binary semaphore for mutex

    srand(time(0));  // Seed for random number generation

    // Create reader threads
    for (int i = 0; i < 5; i++) {
        reader_ids[i] = i + 1;
        pthread_create(&readers[i], NULL, reader, &reader_ids[i]);
    }

    // Create writer threads
    for (int i = 0; i < 2; i++) {
        writer_ids[i] = i + 1;
        pthread_create(&writers[i], NULL, writer, &writer_ids[i]);
    }

    // Join threads (infinite loop, so won't terminate)
    for (int i = 0; i < 5; i++) {
        pthread_join(readers[i], NULL);
    }
    for (int i = 0; i < 2; i++) {
        pthread_join(writers[i], NULL);
    }

    // Destroy semaphores
    sem_destroy(&rw_mutex);
    sem_destroy(&mutex);

    return 0;
}
