#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <time.h>

#define BUFFER_SIZE 5  // Size of the shared buffer

int buffer[BUFFER_SIZE];  // Shared buffer
int in = 0, out = 0;      // Indexes for producer and consumer

sem_t empty;  // Semaphore for empty slots
sem_t full;   // Semaphore for filled slots
pthread_mutex_t mutex;  // Mutex for critical section

// Function to get the current time
void get_time(char* time_str) {
    time_t now = time(NULL);
    strftime(time_str, 100, "%Y-%m-%d %H:%M:%S", localtime(&now));
}

// Producer function
void* producer(void* arg) {
    int item;
    char time_str[100];

    while (1) {
        item = rand() % 100;  // Generate a random item
        sem_wait(&empty);     // Wait if no empty slots
        pthread_mutex_lock(&mutex);  // Enter critical section

        buffer[in] = item;  // Add the item to the buffer
        get_time(time_str);
        printf("Producer produced: %d at %s\n", item, time_str);

        in = (in + 1) % BUFFER_SIZE;  // Update index

        pthread_mutex_unlock(&mutex);  // Exit critical section
        sem_post(&full);  // Signal that a slot is filled

        sleep(rand() % 2);  // Simulate production time
    }
}

// Consumer function
void* consumer(void* arg) {
    int item;
    char time_str[100];

    while (1) {
        sem_wait(&full);  // Wait if no filled slots
        pthread_mutex_lock(&mutex);  // Enter critical section

        item = buffer[out];  // Remove the item from the buffer
        get_time(time_str);
        printf("Consumer consumed: %d at %s\n", item, time_str);

        out = (out + 1) % BUFFER_SIZE;  // Update index

        pthread_mutex_unlock(&mutex);  // Exit critical section
        sem_post(&empty);  // Signal that a slot is empty

        sleep(rand() % 2);  // Simulate consumption time
    }
}

int main() {
    pthread_t prod_thread, cons_thread;  // Thread identifiers

    // Initialize semaphores and mutex
    sem_init(&empty, 0, BUFFER_SIZE);  // Initially, all slots are empty
    sem_init(&full, 0, 0);  // Initially, no slots are filled
    pthread_mutex_init(&mutex, NULL);

    srand(time(0));  // Seed for random number generation

    // Create producer and consumer threads
    pthread_create(&prod_thread, NULL, producer, NULL);
    pthread_create(&cons_thread, NULL, consumer, NULL);

    // Wait for the threads to finish (they won't, as this runs indefinitely)
    pthread_join(prod_thread, NULL);
    pthread_join(cons_thread, NULL);

    // Destroy semaphores and mutex
    sem_destroy(&empty);
    sem_destroy(&full);
    pthread_mutex_destroy(&mutex);

    return 0;
}
