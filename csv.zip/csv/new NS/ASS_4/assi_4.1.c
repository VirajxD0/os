#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <unistd.h>

#define NUM_READERS 3
#define NUM_WRITERS 2

sem_t resource, rmutex;
int read_count = 0; // Number of active readers

void *reader(void *arg) {
    int id = *(int *)arg;

    while (1) {
        sem_wait(&rmutex);
        read_count++;
        if (read_count == 1) // First reader locks the resource
            sem_wait(&resource);
        sem_post(&rmutex);

        // Reading section
        printf("Reader %d is reading.\n", id);
        sleep(1);

        sem_wait(&rmutex);
        read_count--;
        if (read_count == 0) // Last reader unlocks the resource
            sem_post(&resource);
        sem_post(&rmutex);

        sleep(1); // Simulate delay
    }
    return NULL;
}

void *writer(void *arg) {
    int id = *(int *)arg;

    while (1) {
        sem_wait(&resource); // Lock the resource

        // Writing section
        printf("Writer %d is writing.\n", id);
        sleep(2);

        sem_post(&resource); // Unlock the resource
        sleep(1); // Simulate delay
    }
    return NULL;
}

int main() {
    pthread_t readers[NUM_READERS], writers[NUM_WRITERS];
    int ids[NUM_READERS > NUM_WRITERS ? NUM_READERS : NUM_WRITERS];

    // Initialize semaphores
    sem_init(&resource, 0, 1);
    sem_init(&rmutex, 0, 1);

    // Create reader threads
    for (int i = 0; i < NUM_READERS; i++) {
        ids[i] = i + 1;
        pthread_create(&readers[i], NULL, reader, &ids[i]);
    }

    // Create writer threads
    for (int i = 0; i < NUM_WRITERS; i++) {
        ids[i] = i + 1;
        pthread_create(&writers[i], NULL, writer, &ids[i]);
    }

    // Join threads (not reachable in this implementation)
    for (int i = 0; i < NUM_READERS; i++)
        pthread_join(readers[i], NULL);
    for (int i = 0; i < NUM_WRITERS; i++)
        pthread_join(writers[i], NULL);

    // Destroy semaphores
    sem_destroy(&resource);
    sem_destroy(&rmutex);

    return 0;
}
