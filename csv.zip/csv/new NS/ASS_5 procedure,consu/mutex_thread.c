#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

// Shared buffer and its parameters
int *buffer;
int bufferSize, in = 0, out = 0, count = 0; // Buffer and count
pthread_mutex_t mutex;          // Mutex for synchronization
pthread_cond_t notEmpty, notFull; // Condition variables

// Producer function
void *producer(void *param) {
    int itemsToProduce = *((int *)param);
    for (int i = 0; i < itemsToProduce; i++) {
        int item = rand() % 100; // Produce a random item

        pthread_mutex_lock(&mutex);  // Lock the buffer

        // Wait if buffer is full
        while (count == bufferSize)
            pthread_cond_wait(&notFull, &mutex);

        // Add item to the buffer
        buffer[in] = item;
        printf("Producer produced: %d\n", item);
        in = (in + 1) % bufferSize;
        count++;

        pthread_cond_signal(&notEmpty);  // Signal that a slot is filled
        pthread_mutex_unlock(&mutex);    // Unlock the buffer

        sleep(1); // Simulate production delay
    }
    pthread_exit(0);
}

// Consumer function
void *consumer(void *param) {
    int id = *((int *)param);
    while (1) {
        pthread_mutex_lock(&mutex); // Lock the buffer

        // Wait if buffer is empty
        while (count == 0)
            pthread_cond_wait(&notEmpty, &mutex);

        // Consume item from the buffer
        int item = buffer[out];
        printf("Consumer %d consumed: %d\n", id, item);
        out = (out + 1) % bufferSize;
        count--;

        pthread_cond_signal(&notFull); // Signal that a slot is empty
        pthread_mutex_unlock(&mutex);  // Unlock the buffer

        sleep(1); // Simulate consumption delay
    }
    pthread_exit(0);
}

int main() {
    int itemsToProduce;

    // User input for buffer size and number of items
    printf("Enter the size of the buffer: ");
    scanf("%d", &bufferSize);
    printf("Enter the number of items to produce: ");
    scanf("%d", &itemsToProduce);

    buffer = (int *)malloc(bufferSize * sizeof(int)); // Allocate memory for the buffer

    // Initialize mutex and condition variables
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&notEmpty, NULL);
    pthread_cond_init(&notFull, NULL);

    // Create threads for producer and consumers
    pthread_t producerThread, consumerThread1, consumerThread2;
    pthread_create(&producerThread, NULL, producer, &itemsToProduce);

    int consumer1ID = 1, consumer2ID = 2;
    pthread_create(&consumerThread1, NULL, consumer, &consumer1ID);
    pthread_create(&consumerThread2, NULL, consumer, &consumer2ID);

    // Wait for the producer to finish
    pthread_join(producerThread, NULL);

    // Cancel consumers (simulate stopping them after production is complete)
    pthread_cancel(consumerThread1);
    pthread_cancel(consumerThread2);

    // Clean up
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&notEmpty);
    pthread_cond_destroy(&notFull);
    free(buffer);

    printf("Production and consumption completed.\n");
    return 0;
}
