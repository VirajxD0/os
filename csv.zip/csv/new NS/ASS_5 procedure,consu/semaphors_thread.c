#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

// Shared buffer and its parameters
int *buffer;
int bufferSize, in = 0, out = 0;
sem_t emptySlots, fullSlots, mutex; // Semaphores for synchronization

// Producer function
void *producer(void *param) {
    int itemsToProduce = *((int *)param);
    for (int i = 0; i < itemsToProduce; i++) {
        int item = rand() % 100; // Produce a random item

        sem_wait(&emptySlots);  // Wait if no empty slots
        sem_wait(&mutex);       // Lock the buffer

        // Add item to the buffer
        buffer[in] = item;
        printf("Producer produced: %d\n", item);
        in = (in + 1) % bufferSize;

        sem_post(&mutex);       // Unlock the buffer
        sem_post(&fullSlots);   // Signal that a slot is full

        sleep(1); // Simulate production delay
    }
    pthread_exit(0);
}

// Consumer function
void *consumer(void *param) {
    int id = *((int *)param);
    while (1) {
        sem_wait(&fullSlots);  // Wait if no full slots
        sem_wait(&mutex);      // Lock the buffer

        // Consume item from the buffer
        int item = buffer[out];
        printf("Consumer %d consumed: %d\n", id, item);
        out = (out + 1) % bufferSize;

        sem_post(&mutex);      // Unlock the buffer
        sem_post(&emptySlots); // Signal that a slot is empty

        sleep(1); // Simulate consumption delay
    }
    pthread_exit(0);
}

int main() {
    int itemsToProduce;

    // User input for buffer size and number of items
    printf("Enter the size of the buffer: ");
    scanf("%d", &bufferSize);
    printf("Enter the number of items to produce: ");
    scanf("%d", &itemsToProduce);

    buffer = (int *)malloc(bufferSize * sizeof(int)); // Allocate memory for the buffer

    // Initialize semaphores
    sem_init(&emptySlots, 0, bufferSize); // Initially all slots are empty
    sem_init(&fullSlots, 0, 0);           // No slots are full initially
    sem_init(&mutex, 0, 1);               // Mutex starts unlocked

    // Create threads for producer and consumers
    pthread_t producerThread, consumerThread1, consumerThread2;
    pthread_create(&producerThread, NULL, producer, &itemsToProduce);

    int consumer1ID = 1, consumer2ID = 2;
    pthread_create(&consumerThread1, NULL, consumer, &consumer1ID);
    pthread_create(&consumerThread2, NULL, consumer, &consumer2ID);

    // Wait for the producer to finish
    pthread_join(producerThread, NULL);

    // Cancel consumers (simulate stopping them after production is complete)
    pthread_cancel(consumerThread1);
    pthread_cancel(consumerThread2);

    // Clean up
    sem_destroy(&emptySlots);
    sem_destroy(&fullSlots);
    sem_destroy(&mutex);
    free(buffer);

    printf("Production and consumption completed.\n");
    return 0;
}
