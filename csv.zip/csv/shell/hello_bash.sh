#!/bin/bash

echo "hello bash world!"
