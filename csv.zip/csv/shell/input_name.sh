#!/bin/bash

read name

echo "$name aka ben"
