#!/bin/bash

echo "First argument: $1"
echo "Second argument: $2"

